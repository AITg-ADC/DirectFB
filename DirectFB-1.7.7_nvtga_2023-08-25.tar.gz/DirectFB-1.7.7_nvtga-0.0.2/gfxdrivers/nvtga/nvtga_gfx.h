#ifndef __NVTGA_GFX_H__
#define __NVTGA_GFX_H__

#include "hdal.h"

// Driver constants
#define TSI_ACCELERATOR		0x54736930

typedef struct _URECT {
	UINT32  x;                          ///< x coordinate of the top-left point of the rectangle
	UINT32  y;                          ///< y coordinate of the top-left point of the rectangle
	UINT32  w;                          ///< rectangle width
	UINT32  h;                          ///< rectangle height
} URECT;


typedef struct _DIM {
	UINT32 w;                           ///< image width
	UINT32 h;                           ///< image height
} DIM;

/**
 * \brief Gfx device data.
 *
 * Members are set in Gfx_SetState() and callees and used in other functions.
 *
 * @see  Gfx_SetState()
 */
typedef struct {
	unsigned int src_format;		///< Current source surface format
	unsigned int dst_format;		///< Current destination surface format
	unsigned long v_srcAddr;		///< Current source surface physical address
	unsigned int v_srcStride;		///< Current source surface stride
	DFBSurfaceBlendFunction v_srcBlend;	///< Current source surface blend function
	DFBSurfaceBlendFunction v_dstBlend;	///< Current destination surface blend function

	DFBSurfaceDrawingFlags drawingflags;	///< Current drawing flags
	DFBSurfaceBlittingFlags blittingflags;	///< Current blitting flags
	DFBAccelerationMask lastop;		///< Last operation type. Possible values are DFXL_ALL_DRAW, DFXL_ALL_BLIT.
	
	UINT32 color;
	UINT32 colorkey;
	UINT32 colorkey_en;
	unsigned long v_dstAddr;
	unsigned int v_dstStride;
	UINT32 state_is_set;
       	URECT src_region;//<src region
       	URECT dst_region;//<dst region 
        DIM src_dim;//<src image dim 
        DIM dst_dim;//<dst image dim  
} Gfx_DeviceData;

/**
 * \brief Gfx driver data.
 */
typedef struct {
     //  UINT8 src_ddrid;//<indicate v_srcAddr@ddr id
     //  UINT8 dst_ddrid;//<indicate v_dstAddr@ddr id   
       UINT8 thickness;//<indicate line thickness
} Gfx_DriverData;

#endif
