/*
   (c) Copyright 2001-2009  The world wide DirectFB Open Source Community (directfb.org)
   (c) Copyright 2000-2004  Convergence (integrated media) GmbH

   All rights reserved.

   This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.

   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the
   Free Software Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.

   Changelog:
   Wed Mar 17 2010, version 0.1: First version
*/

#include <stdio.h>
#include <memory.h>
#include <fcntl.h>

#include <sys/mman.h>
#include <sys/ioctl.h>
#include <fbdev/fbdev.h>

#include <directfb.h>
#include <core/graphics_driver.h>

#include <core/gfxcard.h>
#include <core/screens.h>
#include <core/surface.h>
#include <core/palette.h>
#include <core/system.h>

//#include "gfx.h"
#include "nvtga_gfx.h"
#include "hd_gfx.h"
#include "vendor_gfx.h"
#include "vendor_common.h"

/// Enables debug messages for graphics operations
//#define DEBUG_OPERATIONS

#ifdef DEBUG_OPERATIONS
#define DEBUG_OP(args...)   printf(args)
#else
#define DEBUG_OP(args...)
#endif

/// Enables debug messages on procedure entry.
//#define DEBUG_PROCENTRY

#ifdef DEBUG_PROCENTRY
#define DEBUG_PROC_ENTRY    do { printf("* %s\n", __FUNCTION__); } while (0)
#else
#define DEBUG_PROC_ENTRY
#endif

DFB_GRAPHICS_DRIVER(nvtga)

// Color conversion macros

#define GFX_ARGB(a,r,g,b)  (((b) & 0x000000ff) << 24 | ((g) & 0x000000ff) << 16 | ((r) & 0x000000ff) << 8 | ((a) & 0x000000ff))

#define OPAQUE(color)           ((color) | 0x000000FF)
#define TRANSP(alpha, color)    ((color) & 0xFFFFFF00 | (alpha))

#define GFX_SUPPORTED_DRAWINGFUNCTIONS (DFXL_FILLRECTANGLE|DFXL_DRAWRECTANGLE|DFXL_DRAWLINE|DFXL_ALL_DRAW)
#define GFX_SUPPORTED_BLITTINGFUNCTIONS (DFXL_BLIT)
#define GFX_SUPPORTED_DRAWINGFLAGS 0
#define GFX_SUPPORTED_BLITTINGFLAGS 0

static void Gfx_EngineReset(void *drv, void *dev);
static bool Gfx_DrawRectangle(void *drv, void *dev,  DFBRectangle *rect);

/**
 * Converts from DirectFB to  surface pixel format constants
 * and also performs validation for unsupported source or
 * destination formats.
 *
 * As of DirectFB YUV pixel format defines are somewhat confusing, so
 * the following may need to change in the future.
 *
 * @param format A DirectFB surface pixel format constant, defined in include/directfb.h
 * @param flag Indicates whether it is a source of destination surface. Possible values are SMF_SOURCE, SMF_DESTINATION.
 */
static inline HD_VIDEO_PXLFMT gfx_video_mode(DFBSurfacePixelFormat format)
{
    switch (format) {
    case DSPF_ARGB:
        return HD_VIDEO_PXLFMT_ARGB8888;
    case DSPF_ARGB1555:
        return HD_VIDEO_PXLFMT_ARGB1555;
    default:
        //     printf("%s:not support format=%#x\n", __func__, format);
        return HD_VIDEO_PXLFMT_ARGB1555;
    }
}

/**
 * Sets blit source.
 *
 * Needs to save source address and pitch because Blit or StretchBlit
 * may specify source coordinates and we lack a source
 * XY register.
 *
 * @param tdrv Driver data
 * @param tdev Device data
 * @param state Card state
 */
static inline int gfx_set_src(Gfx_DeviceData *gfxdev, CardState  *state)
{
    DEBUG_PROC_ENTRY;

    if (!state->src.phys || !state->src.pitch) {
        printf("directfb:invalid src buffer(0x%lx) or lineoffset(%d)\n", state->src.phys, state->src.pitch);
        return -1;
    }
    DEBUG_OP("gfx_set_src:pitch=%d size(%d %d)\n", state->src.pitch, state->source->config.size.w,
             state->source->config.size.h);
    gfxdev->v_srcAddr = state->src.phys;
    gfxdev->v_srcStride = state->src.pitch;
    gfxdev->src_dim.w = state->source->config.size.w;
    gfxdev->src_dim.h = state->source->config.size.h;
    return 0;
}


/**
 * Sets destination surface registers.
 *
 * @param tdrv Driver data
 * @param tdev Device data
 * @param state Card state
 */
static inline int gfx_set_dest(Gfx_DeviceData *gfxdev, CardState  *state)
{
    DEBUG_PROC_ENTRY;

    if (!state->dst.phys || !state->dst.pitch) {
        printf("directfb:invalid dst buffer(0x%lx) or lineoffset(%d)\n", state->dst.phys, state->dst.pitch);
        return -1;
    }
    DEBUG_OP("gfx_set_dest:pitch=%d size(%d %d)\n", state->dst.pitch, state->destination->config.size.w,
             state->destination->config.size.h);
    gfxdev->v_dstAddr = state->dst.phys;
    gfxdev->v_dstStride = state->dst.pitch;
    gfxdev->dst_dim.w = state->destination->config.size.w;
    gfxdev->dst_dim.h = state->destination->config.size.h;
    return 0;
}

/**
 * Sets colorization color.
 *
 * Sets the color to be used for colorizing _or_ color modulation
 * with alpha value. The latter is essentially identical to colorizing
 * but using the alpha value instead of an RGB color.
 *
 * @param tdrv Driver data
 * @param tdev Device data
 * @param state Card state
 */

static inline int gfx_set_color(Gfx_DeviceData *gfxdev, CardState *state)
{
    DEBUG_PROC_ENTRY;
    int ret = 0;

    if (gfxdev->dst_format == HD_VIDEO_PXLFMT_ARGB8888) {
        gfxdev->color = GFX_ARGB(state->color.a, state->color.r, state->color.g, state->color.b);
    } else if (gfxdev->dst_format == HD_VIDEO_PXLFMT_ARGB1555) {
        gfxdev->color = GFX_ARGB(state->color.a, state->color. r >> 3, state->color.g >> 3, state->color.b >> 3); //transfer
        // argb8888 color to argb15555 color value
    } else {
        ret = -1;
    }
    DEBUG_OP("%s:color=%#x dst_format=%#x state.color(%d %d %d %d)\n", __func__, gfxdev->color, gfxdev->dst_format,
             state->color.a, state->color.r, state->color.g, state->color.b);
    return ret;
}

static UINT32 convert_stride_to_width(UINT32 stride, unsigned int fmt)
{
    if (fmt == HD_VIDEO_PXLFMT_ARGB8888) {
        return (stride >> 2);
    } else if (fmt == HD_VIDEO_PXLFMT_ARGB1555) {
        return (stride >> 1);
    } else {
        printf("Not support fmt(%#x)\n", fmt);
        return (stride >> 1);
    }
}

/**
 * DirectFB callback that decides whether a drawing/blitting operation is supported in hardware.
 *
 * @param drv Driver data
 * @param dev Device data
 * @param state Card state
 * @param accel Acceleration mask
 */
static void Gfx_CheckState(void *drv, void *dev, CardState *state, DFBAccelerationMask  accel)
{
    CoreSurface *source = state->source;
    CoreSurface *destination = state->destination;

    DEBUG_PROC_ENTRY;

    DEBUG_OP("Checking for %d...\n", accel);

    /* reject if we don't support the destination format */
    if (gfx_video_mode(destination->config.format) == HD_VIDEO_PXLFMT_NONE) {
        DEBUG_OP("Check dst fmt fail\n");
        return;
    }

    if (DFB_DRAWING_FUNCTION(accel)) {
        /* reject if:
         *  - we don't support the drawing function
         *  - we don't support the drawing flag */
        if (accel & ~GFX_SUPPORTED_DRAWINGFUNCTIONS || state->drawingflags & ~GFX_SUPPORTED_DRAWINGFLAGS) {
            DEBUG_OP("Check draw function with accel(%#x) fail\n", accel);
            return;
        }

        state->accel |= GFX_SUPPORTED_DRAWINGFUNCTIONS;
    } else {
        if (gfx_video_mode(source->config.format) == HD_VIDEO_PXLFMT_NONE) {
            DEBUG_OP("Check src fmt fail\n");
            return;
        }

        state->accel |= GFX_SUPPORTED_BLITTINGFUNCTIONS;
    }

    DEBUG_OP("    ...we'll do it.\n");
}

/**
 * DirectFB callback that prepares the hardware for a drawing/blitting operation.
 *
 * @param drv Driver data
 * @param dev Device data
 * @param funcs Graphics device functions (may be altered)
 * @param state Card state
 * @param accel Acceleration mask
 */
static void Gfx_SetState(void *driver_data, void *dev, GraphicsDeviceFuncs *funcs, CardState *state, DFBAccelerationMask  accel)
{
    Gfx_DeviceData *gfxdev      = (Gfx_DeviceData *) dev;
    CoreSurface *destination      = state->destination;
    StateModificationFlags mod_hw = state->mod_hw;

    DEBUG_PROC_ENTRY;
    DEBUG_OP("Gfx_SetState:accel=%#x\n", accel);
    gfxdev->state_is_set = 1;
    if (accel != DFXL_DRAWRECTANGLE && accel != DFXL_DRAWLINE && accel != DFXL_FILLRECTANGLE && accel != DFXL_BLIT) {
        return;
    }

    /* update first the drawing and blitting flags */
    if (mod_hw & SMF_DRAWING_FLAGS) {
        gfxdev->drawingflags = state->drawingflags;
    }
    if (mod_hw & SMF_BLITTING_FLAGS) {
        gfxdev->blittingflags = state->blittingflags;
    }

    gfxdev->dst_format = gfx_video_mode(destination->config.format);
    if (gfxdev->dst_format == HD_VIDEO_PXLFMT_NONE) {
        return;
    }
    if (gfx_set_dest(gfxdev, state)) {
        return;
    }
    if (mod_hw & SMF_SRC_COLORKEY && state->dst_colorkey) {
        return;
    }
    if (mod_hw & SMF_DST_COLORKEY && state->dst_colorkey) {
        return;
    }
    if (mod_hw & SMF_SRC_BLEND) {
        if (state->src_blend != DSBF_SRCALPHA) {
            return;
        } else {
            gfxdev->v_srcBlend = state->src_blend;
        }
    }
    if (mod_hw & SMF_DST_BLEND) {
        if (state->dst_blend != DSBF_INVSRCALPHA) {
            return;
        } else {
            gfxdev->v_dstBlend = state->dst_blend;
        }
    }
    switch (accel) {
    case DFXL_DRAWRECTANGLE:
    case DFXL_DRAWLINE:
    case DFXL_FILLRECTANGLE:
        if (mod_hw & SMF_COLOR) {
            if (gfx_set_color(gfxdev, state)) {
                return;
            }
        }
        state->set |= accel;
        gfxdev->lastop = DFXL_ALL_DRAW;
        gfxdev->state_is_set = 1;
        break;

    case DFXL_BLIT:
    case DFXL_ALL_BLIT:
    case DFXL_STRETCHBLIT:
        gfxdev->src_format = gfx_video_mode(state->source->config.format);
        if (gfxdev->src_format == HD_VIDEO_PXLFMT_NONE) {
            printf("directfb:gfx_video_mode(%x,src) fail\n", state->source->config.format);
            return;
        }
        if (gfx_set_src(gfxdev, state)) {
            printf("directfb:t2d_set_src() fail\n");
            return;
        }

        state->set |= accel;
        gfxdev->lastop = DFXL_ALL_BLIT;
        gfxdev->state_is_set = 1;
        break;
    default:
        D_BUG("Unexpected drawing/blitting function");
    }

    state->mod_hw = 0;
}
/**
 * DirectFB callback that draws a line.
 *
 * @param drv Driver data
 * @param dev Device data
 * @param line Line region
 */
static bool Gfx_DrawLine(void *drv, void *dev, DFBRegion *line)
{
    Gfx_DriverData *gfxdrv = (Gfx_DriverData *)drv;
    Gfx_DeviceData *gfxdev  = (Gfx_DeviceData *)dev;
    HD_GFX_DRAW_LINE gfx_line;
    DEBUG_PROC_ENTRY;

    DEBUG_OP("Gfx_DrawLine:start (%d %d) end(%d, %d)\n", line->x1, line->y1, line->x2, line->y2);

    gfx_line.color = gfxdev->color;
    gfx_line.dst_img.dim.w =  convert_stride_to_width(gfxdev->v_dstStride, gfxdev->dst_format);
    gfx_line.dst_img.dim.h = gfxdev->dst_dim.h;
    gfx_line.dst_img.format = gfxdev->dst_format;

    gfx_line.dst_img.p_phy_addr[0] = gfxdev->v_dstAddr;
    gfx_line.dst_img.ddr_id = DDR_ID0;
    gfx_line.thickness = gfxdrv->thickness;
    gfx_line.start.x = line->x1;
    gfx_line.start.y = line->y1;
    gfx_line.end.x =  line->x2;
    gfx_line.end.y = line->y2;

    if (vendor_gfx_draw_lines(&gfx_line, 1) != HD_OK) {
        printf("vendor_gfx_draw_lines single fail\n");
        return false;
    } else {
        DEBUG_OP("gfx_draw_lines OK\n");
    }

    return true;
}

static bool Gfx_DrawLines(void *drv, void *dev, DFBRegion *line, int line_num)
{
    Gfx_DriverData *gfxdrv = (Gfx_DriverData *)drv;
    Gfx_DeviceData *gfxdev  = (Gfx_DeviceData *)dev;
    HD_GFX_DRAW_LINE *gfx_line= NULL;
    DEBUG_PROC_ENTRY;
    unsigned int  i;
    
    gfx_line = calloc(line_num, sizeof(HD_GFX_DRAW_LINE));
   if (!gfx_line) {
           printf("Gfx_DrawLines: calloc fail\n");
           return false;
   }
    for (i = 0; i < line_num; i++) {
        DEBUG_OP("Gfx_DrawLine:start (%d %d) end(%d, %d)\n", line[i].x1, line[i].y1, line[i].x2, line[i].y2);
    }
    for (i = 0; i < line_num; i++) {
        gfx_line[i].color = gfxdev->color;
        gfx_line[i].dst_img.dim.w =  convert_stride_to_width(gfxdev->v_dstStride, gfxdev->dst_format);
        gfx_line[i].dst_img.dim.h = gfxdev->dst_dim.h;
        gfx_line[i].dst_img.format = gfxdev->dst_format;

        gfx_line[i].dst_img.p_phy_addr[0] = gfxdev->v_dstAddr;
        gfx_line[i].dst_img.ddr_id = DDR_ID0;
        gfx_line[i].thickness = gfxdrv->thickness;
        gfx_line[i].start.x = line[i].x1;
        gfx_line[i].start.y = line[i].y1;
        gfx_line[i].end.x =  line[i].x2;
        gfx_line[i].end.y = line[i].y2;
    }
    if (vendor_gfx_draw_lines(gfx_line, line_num) != HD_OK) {
        printf("vendor_gfx_draw_lines %d fail\n", line_num);
        if (gfx_line) {
            free(gfx_line);
         }
        return false;
    } else {
        DEBUG_OP("gfx_draw_lines %dlines  OK\n", line_num);
    }
    if (gfx_line) {
        free(gfx_line);
     }
    return true;
}


/**
 * DirectFB callback that draws a filled rectangle.
 *
 * @param drv Driver data
 * @param dev Device data
 * @param rect Rectangle coordinates
 */
static bool Gfx_FillRectangle(void *drv, void  *dev, DFBRectangle *rect)
{
    Gfx_DeviceData *gfxdev  = (Gfx_DeviceData *)dev;
    HD_GFX_DRAW_RECT   gfx_rect = {0};
    DEBUG_PROC_ENTRY;

    DEBUG_OP("Gfx_FillRectangle: rect(%d %d %dx%d) color(%#x)\n",  rect->x, rect->y, rect->w, rect->h, gfxdev->color);

    gfx_rect.color = gfxdev->color;
    gfx_rect.dst_img.dim.w = convert_stride_to_width(gfxdev->v_dstStride, gfxdev->dst_format);

    gfx_rect.dst_img.dim.h =  gfxdev->dst_dim.h;
    gfx_rect.dst_img.format =  gfxdev->dst_format;
    gfx_rect.dst_img.ddr_id = DDR_ID0;

    gfx_rect.dst_img.p_phy_addr[0] = gfxdev->v_dstAddr;
    gfx_rect.rect.x = rect->x;
    gfx_rect.rect.y = rect->y;
    gfx_rect.rect.w = rect->w;
    gfx_rect.rect.h = rect->h;
    gfx_rect.type = HD_GFX_RECT_SOLID;
    if (vendor_gfx_draw_rects(&gfx_rect, 1) != HD_OK) {
        printf("vendor_gfx_draw_rects single fail\n");
        return false;
    } else {
        DEBUG_OP("gfx_draw_rects dst_fmt(%#x) num(%d) done\n", gfx_rect.dst_img.format, 1);
   }
    return true;
}

/**
 * DirectFB callback that draws a filled rectangles.
 *
 * @param drv Driver data
 * @param dev Device data
 * @param rect Rectangle coordinates
 */
static bool Gfx_FillRectangles(void *drv, void  *dev, const DFBRectangle *rect, unsigned int num, unsigned int *ret_num)
{
    Gfx_DeviceData *gfxdev  = (Gfx_DeviceData *)dev;
    HD_GFX_DRAW_RECT   *gfx_rect = NULL;
    unsigned int  i;

    DEBUG_PROC_ENTRY;

    gfx_rect = calloc(num, sizeof(HD_GFX_DRAW_RECT));
    if (!gfx_rect) {
        printf("Gfx_FillRectangles: calloc fail\n");
        return false;
    }
#ifdef DEBUG_OPERATIONS
    for (i = 0; i < num; i++) {
        DEBUG_OP("Gfx_FillRectangles: rect(%d %d %dx%d) color(%#x)\n",  rect[i].x, rect[i].y, rect[i].w, rect[i].h, gfxdev->color);
    }
#endif
    for (i = 0; i < num; i++) {
        gfx_rect[i].color = gfxdev->color;
        gfx_rect[i].dst_img.dim.w = convert_stride_to_width(gfxdev->v_dstStride, gfxdev->dst_format);

        gfx_rect[i].dst_img.dim.h =  gfxdev->dst_dim.h;
        gfx_rect[i].dst_img.format =  gfxdev->dst_format;
        gfx_rect[i].dst_img.ddr_id = DDR_ID0;

        gfx_rect[i].dst_img.p_phy_addr[0] = gfxdev->v_dstAddr;
        gfx_rect[i].rect.x = rect[i].x;
        gfx_rect[i].rect.y = rect[i].y;
        gfx_rect[i].rect.w = rect[i].w;
        gfx_rect[i].rect.h = rect[i].h;
        gfx_rect[i].type = HD_GFX_RECT_SOLID;
    }
    if (vendor_gfx_draw_rects(gfx_rect, num) != HD_OK) {
        printf("vendor_gfx_draw_rects mutli-rects fail\n");
        if (gfx_rect) {
            free(gfx_rect);
        }
        return false;
    } else {
        *ret_num = num;
        DEBUG_OP("gfx_draw_rects dst_fmt(%#x) num(%d) done\n", gfxdev->dst_format, num);
    }
    if (gfx_rect) {
        free(gfx_rect);
    }
    return true;
}


static bool Gfx_Blit(void *drv, void *dev, DFBRectangle *rect, int dx, int dy)
{
    Gfx_DeviceData *gfxdev  = (Gfx_DeviceData *)dev;
    HD_GFX_COPY        copy_param = {0};

    DEBUG_PROC_ENTRY;

    DEBUG_OP("Gfx_Blit: dst_xy(%d, %d), dst_rect(%d %d %dx%d) dst_format(%#x) dst_dim(%dx%d)  src_dim(%dx%d)\n", dx, dy, 
        rect->x, rect->y,rect->w, rect->h, gfxdev->dst_format, gfxdev->dst_dim.w, gfxdev->dst_dim.h, gfxdev->src_dim.w, gfxdev->src_dim.h);

    //set dst pot
    copy_param.dst_pos.x = dx;
    copy_param.dst_pos.y = dy;

    copy_param.src_region.x = rect->x;
    copy_param.src_region.y = rect->y;
    copy_param.src_region.w = rect->w;
    copy_param.src_region.h = rect->h;

    copy_param.src_img.dim.w = convert_stride_to_width(gfxdev->v_srcStride, gfxdev->src_format);
    copy_param.src_img.dim.h = gfxdev->src_dim.h;
    copy_param.src_img.format = gfxdev->src_format;
    copy_param.src_img.p_phy_addr[0] = gfxdev->v_srcAddr;
    copy_param.src_img.ddr_id = DDR_ID0;
    copy_param.dst_img.dim.w = convert_stride_to_width(gfxdev->v_dstStride, gfxdev->dst_format);
    copy_param.dst_img.dim.h = gfxdev->dst_dim.h;
    copy_param.dst_img.format = gfxdev->dst_format;
    copy_param.dst_img.p_phy_addr[0] = gfxdev->v_dstAddr;
    copy_param.dst_img.ddr_id = DDR_ID0;


    if (vendor_gfx_copy(&copy_param, 1) != HD_OK) {
        printf("vendor_gfx_copy single fail\n");
        return false;
    } else {
        DEBUG_OP("gfx_copy_imgs done\n");
    }

    return true;
}

static bool Gfx_BatchBlit( void *driver_data, void *device_data,
                        const DFBRectangle *rects, const DFBPoint *points,
                        unsigned int num, unsigned int *ret_num)
{
    Gfx_DeviceData *gfxdev  = (Gfx_DeviceData *)device_data;
    HD_GFX_COPY  *copy_param = NULL;
    unsigned int  i;
     
    DEBUG_PROC_ENTRY;

    copy_param = calloc(num, sizeof(HD_GFX_COPY));
    if (!copy_param) {
        printf("Gfx_BatchBlit: calloc fail\n");
        return false;
    }
    
    DEBUG_OP("Gfx_Blit: \n");
    for (i = 0; i < num; i++) {
        DEBUG_OP("   point_%d(%d, %d), dst_rect(%d %d %dx%d) dst_format(%#x) dev_dst_dim(%dx%d)  dev_src_dim(%dx%d)\n", i, points[i].x, points[i].y, 
            rects[i].x, rects[i].y,  rects[i].w, rects[i].h, gfxdev->dst_format, gfxdev->dst_dim.w, gfxdev->dst_dim.h, gfxdev->src_dim.w, gfxdev->src_dim.h);
    }
    //set dst pot
    for (i = 0; i < num; i++) {
        copy_param[i].dst_pos.x = points[i].x;
        copy_param[i].dst_pos.y = points[i].y;

        copy_param[i].src_region.x = rects[i].x;
        copy_param[i].src_region.y = rects[i].y;
        copy_param[i].src_region.w = rects[i].w;
        copy_param[i].src_region.h = rects[i].h;

        copy_param[i].src_img.dim.w = convert_stride_to_width(gfxdev->v_srcStride, gfxdev->src_format);
        copy_param[i].src_img.dim.h = gfxdev->src_dim.h;
        copy_param[i].src_img.format = gfxdev->src_format;
        copy_param[i].src_img.p_phy_addr[0] = gfxdev->v_srcAddr;
        copy_param[i].src_img.ddr_id = DDR_ID0;
        copy_param[i].dst_img.dim.w = convert_stride_to_width(gfxdev->v_dstStride, gfxdev->dst_format);
        copy_param[i].dst_img.dim.h = gfxdev->dst_dim.h;
        copy_param[i].dst_img.format = gfxdev->dst_format;
        copy_param[i].dst_img.p_phy_addr[0] = gfxdev->v_dstAddr;
        copy_param[i].dst_img.ddr_id = DDR_ID0;
    }
    if (vendor_gfx_copy(copy_param, num) != HD_OK) {
        printf("vendor_gfx_copy single fail\n");
          if (copy_param) {
            free(copy_param);
        }
        return false;
    } else {
        DEBUG_OP("gfx_copy_imgs %d done\n", num);
        *ret_num = num;
    }
    if (copy_param) {
        free(copy_param);
    }
    return true;
}

/**
 * DirectFB callback that does a stretched blit.
 *
 * We use information saved on t2d_set_src() to also set the
 * source address register. See t2d_set_src(). We also
 * compute the scaling coefficients in the fixed point
 * format expected by the hardware.
 *
 * @param drv Driver data
 * @param dev Device data
 * @param srect Source rectangle
 * @param drect Destination rectangle
 */
static bool Gfx_StretchBlit(void *drv, void  *dev, DFBRectangle *srect,  DFBRectangle *drect)
{
//        Gfx_DriverData *gfxdrv = (Gfx_DriverData *)drv;
    Gfx_DeviceData *gfxdev  = (Gfx_DeviceData *)dev;
    HD_GFX_SCALE  scale_param = {0};

    DEBUG_PROC_ENTRY;

    DEBUG_OP("Gfx_StretchBlit (%d, %d), %dx%d\n", drect->x, drect->y, drect->w, drect->h);

    //set dst rect
    scale_param.dst_region.x = drect->x;
    scale_param.dst_region.y = drect->y;
    scale_param.dst_region.w = drect->w;
    scale_param.dst_region.h = drect->h;

    scale_param.src_region.x = srect->x;
    scale_param.src_region.y = srect->y;
    scale_param.src_region.w = srect->w;
    scale_param.src_region.h = srect->h;

    scale_param.src_img.dim.w = convert_stride_to_width(gfxdev->v_srcStride, gfxdev->src_format);
    scale_param.src_img.dim.h = gfxdev->src_dim.h;//(srect->y + srect->h);
    scale_param.src_img.format = gfxdev->src_format;
    scale_param.src_img.p_phy_addr[0] = gfxdev->v_srcAddr;
    scale_param.src_img.ddr_id = DDR_ID0;//gfxdrv->src_ddrid;
    scale_param.dst_img.dim.w = convert_stride_to_width(gfxdev->v_dstStride, gfxdev->dst_format);
    scale_param.dst_img.dim.h = (drect->y + drect->h);
    scale_param.dst_img.format = gfxdev->dst_format;
    scale_param.dst_img.p_phy_addr[0] = gfxdev->v_dstAddr;
    scale_param.dst_img.ddr_id = DDR_ID0;//gfxdrv->dst_ddrid;
    scale_param.quality = 0;

    if (vendor_gfx_scale(&scale_param, 128, 1) != HD_OK) {
        printf("vendor_gfx_scale single fail\n");
        return false;
    }

    return true;
}

/**
 * DirectFB callback that draws a rectangle.
 *
 * Drawing the rectangle is implemented as drawing 4 lines
 * in driver level.
 *
 * @param drv Driver data
 * @param dev Device data
 * @param rect Rectangle coordinates
 */
static bool Gfx_DrawRectangle(void *drv, void *dev,  DFBRectangle *rect)
{
    Gfx_DeviceData *gfxdev  = (Gfx_DeviceData *)dev;
    HD_GFX_DRAW_RECT   gfx_rect = {0};

    DEBUG_PROC_ENTRY;

    DEBUG_OP("DrawRectangle (%d, %d %dx%d) color(%#x)\n", rect->x, rect->y, rect->w, rect->h, gfxdev->color);

    gfx_rect.color = gfxdev->color;
    gfx_rect.dst_img.dim.w = convert_stride_to_width(gfxdev->v_dstStride, gfxdev->dst_format);
    gfx_rect.dst_img.dim.h =  gfxdev->dst_dim.h;
    gfx_rect.dst_img.format =  gfxdev->dst_format;
    gfx_rect.dst_img.ddr_id = DDR_ID0;
    gfx_rect.thickness = 2;
    gfx_rect.dst_img.p_phy_addr[0] = gfxdev->v_dstAddr;
    if (rect->y >= gfx_rect.thickness) {
        gfx_rect.rect.y = rect->y - gfx_rect.thickness;
    } else {
        gfx_rect.rect.y = gfx_rect.thickness;
    }
    if (rect->x >= gfx_rect.thickness) {
        gfx_rect.rect.x = rect->x - gfx_rect.thickness;
    } else {
        gfx_rect.rect.x = gfx_rect.thickness;
    }
    if (rect->w > gfx_rect.thickness) {
        gfx_rect.rect.w = rect->w - gfx_rect.thickness;
    } else {
        gfx_rect.rect.w = gfx_rect.thickness;
    }
    if (rect->h > gfx_rect.thickness) {
        gfx_rect.rect.h = rect->h - gfx_rect.thickness;
    } else {
        gfx_rect.rect.h = gfx_rect.thickness;
    }
    gfx_rect.type = HD_GFX_RECT_HOLLOW;
    if (vendor_gfx_draw_rects(&gfx_rect, 1) != HD_OK) {
        printf("vendor_gfx_draw_rects single fail\n");
        return false;
    } else {
        DEBUG_OP("gfx_draw_rects OK,dst_fmt(%#x)\n", gfx_rect.dst_img.format);
    }

    return true;
}


/**
 * DirectFB callback that resets the hardware.
 *
 * We try to reset the hardware a number of times. We also invalidate
 * DirectFB's saved state because we have also reset all registers,
 * including the destination registers.
 *
 * @param drv Driver data
 * @param dev Device data
 */
static void Gfx_EngineReset(void *drv, void *dev)
{
    memset(dev, 0, sizeof(Gfx_DeviceData));
    dfb_gfxcard_invalidate_state();
}

/**
 * DirectFB callback that blocks until hardware processing has finished.
 *
 * If building with command list support, Think2D_EngineSync() functions
 * just as Think2D_EngineNext() that also restarts the hardware as long
 * as there are unprocessed operations. Otherwise, we simply spin on the
 * hardware status.
 *
 * @param drv Driver data
 * @param dev Device data
 */
static DFBResult Gfx_EngineSync(void *drv, void *dev)
{
    //  DEBUG_PROC_ENTRY;
    return DFB_OK;
}

/**
 * DirectFB driver framework function that probes a device for use with a driver.
 *
 * @param device Graphics device
 */
static int driver_probe(CoreGraphicsDevice *device)
{
    DEBUG_PROC_ENTRY;
    printf("directfb:acc is %d vs %d. always return 1\n", dfb_gfxcard_get_accelerator(device), TSI_ACCELERATOR);
    return 1;
}

/**
 * DirectFB driver framework function that provides info about a driver.
 *
 * @param device Graphics device
 * @param info Driver info
 */
static void driver_get_info(CoreGraphicsDevice *device, GraphicsDriverInfo *info)
{

    DEBUG_PROC_ENTRY;

    snprintf(info->name,    DFB_GRAPHICS_DRIVER_INFO_NAME_LENGTH,    "GFX");
    snprintf(info->vendor,  DFB_GRAPHICS_DRIVER_INFO_VENDOR_LENGTH,  "NOVATEK Ltd.");
    snprintf(info->license, DFB_GRAPHICS_DRIVER_INFO_LICENSE_LENGTH, "LGPL");

    info->version.major = 1;
    info->version.minor = 0;

    info->driver_data_size = sizeof(Gfx_DriverData);
    info->device_data_size = sizeof(Gfx_DeviceData);
}

/**
 * DirectFB driver framework function that initializes a driver.
 *
 * @param device Graphics device
 * @param funcs Device functions
 * @param driver_data Driver data
 * @param device_data Device data
 * @param core DirectFB core object
 */
static DFBResult driver_init_driver(CoreGraphicsDevice   *device, GraphicsDeviceFuncs *funcs, void  *driver_data,
                                    void *device_data, CoreDFB *core)
{
    DEBUG_PROC_ENTRY;

    /* init hdal and allocate memory */

    /* assign system functions */
    funcs->AfterSetVar       = NULL;
    funcs->EngineReset       = Gfx_EngineReset;
    funcs->EngineSync        = Gfx_EngineSync;
    funcs->InvalidateState   = NULL;
    funcs->FlushTextureCache = NULL;
    funcs->FlushReadCache    = NULL;
    funcs->SurfaceEnter      = NULL;
    funcs->SurfaceLeave      = NULL;
    funcs->GetSerial         = NULL;
    funcs->WaitSerial        = NULL;
    funcs->EmitCommands      = NULL;
    funcs->CheckState        = Gfx_CheckState;
    funcs->SetState          = Gfx_SetState;

    /* assign drawing functions */
    funcs->FillRectangle     = Gfx_FillRectangle;
    funcs->DrawRectangle     = Gfx_DrawRectangle;
    funcs->DrawLine          = Gfx_DrawLine;
    funcs->FillTriangle      = NULL;
    funcs ->BatchFill  = Gfx_FillRectangles;    
    /* assign blitting functions */
    funcs->Blit              = Gfx_Blit;
    funcs ->BatchBlit  = Gfx_BatchBlit;
    funcs->StretchBlit       = Gfx_StretchBlit;
    funcs->TextureTriangles  = NULL;

    /* assign other functions */
    funcs->StartDrawing      = NULL;
    funcs->StopDrawing       = NULL;

    printf("directfb:driver init ok\n");

    return DFB_OK;
}

/**
 * DirectFB driver framework function that initializes a device for use with a driver.
 *
 * @param device Graphics device
 * @param device_info Graphics device info
 * @param drv Driver data
 * @param dev Device data
 */
static DFBResult driver_init_device(CoreGraphicsDevice *device,
                                    GraphicsDeviceInfo *device_info,  void *drv, void  *dev)
{
    Gfx_DriverData *gfxdrv = (Gfx_DriverData *) drv;
    Gfx_DeviceData *gfxdev = (Gfx_DeviceData *) dev;

    DEBUG_PROC_ENTRY;
    Gfx_EngineReset(gfxdrv, gfxdev);

    snprintf(device_info->name,   DFB_GRAPHICS_DEVICE_INFO_NAME_LENGTH,   "NovaGfx");
    snprintf(device_info->vendor, DFB_GRAPHICS_DEVICE_INFO_VENDOR_LENGTH, "NOVATEK");

    device_info->caps.accel    = GFX_SUPPORTED_DRAWINGFUNCTIONS | GFX_SUPPORTED_BLITTINGFUNCTIONS;
    device_info->caps.drawing  = GFX_SUPPORTED_DRAWINGFLAGS;
    device_info->caps.blitting = GFX_SUPPORTED_BLITTINGFLAGS;

    device_info->limits.surface_byteoffset_alignment = 4;
    device_info->limits.surface_bytepitch_alignment = 4;
    hd_gfx_init();

    return DFB_OK;
}

/**
   * DirectFB driver framework function that closes a device.
   *
   * @param device Graphics device
   * @param driver_data Driver data
   * @param device_data Device data
   */
static void driver_close_device(CoreGraphicsDevice *device, void *driver_data, void  *device_data)
{
    hd_gfx_uninit();
    DEBUG_PROC_ENTRY;
}

/**
* DirectFB driver framework function that closes a driver.
     *
     * @param device Graphics device
     * @param driver_data Driver data
     */
static void driver_close_driver(CoreGraphicsDevice *device, void *driver_data)
{
    DEBUG_PROC_ENTRY;
}

